package com.zybooks.projecttwo;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.zybooks.projecttwo.db.Helper;
import com.zybooks.projecttwo.db.UserContract;

public class AccountCreationFragment extends Fragment {

    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_account_creation, container, false);

        usernameEditText = view.findViewById(R.id.userText);
        passwordEditText = view.findViewById(R.id.passText);

        Button submitButton = view.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the username and password from EditText fields
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();
                // Insert the new user into the database
                addUserToDatabase(username, password);
            }
        });

        return view;
    }
    private void addUserToDatabase(String username, String password) {
        // Get an instance of the writable database
        SQLiteDatabase database = new Helper(requireContext()).getWritableDatabase();

        // Create a ContentValues object to hold the user data
        ContentValues values = new ContentValues();
        values.put(UserContract.UserEntry.COLUMN_USERNAME, username);
        values.put(UserContract.UserEntry.COLUMN_PASSWORD, password);

        // Insert the new user into the database
        long newRowId = database.insert(UserContract.UserEntry.TABLE_NAME, null, values);

        // Check if the insertion was successful
        if (newRowId != -1) {
            // User inserted successfully
            Toast.makeText(requireContext(), "User created successfully", Toast.LENGTH_SHORT).show();
        } else {
            // Error inserting user
            Toast.makeText(requireContext(), "Failed to create user", Toast.LENGTH_SHORT).show();
        }

        // Close the database connection
        database.close();
    }
}
