package com.zybooks.projecttwo;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.zybooks.projecttwo.data.UserRepository;
import com.zybooks.projecttwo.db.Helper;
import com.zybooks.projecttwo.db.UserContract;
import android.Manifest;

public class MainActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Check if permission is already granted
            super.onCreate(savedInstanceState);
            EdgeToEdge.enable(this);
            setContentView(R.layout.login_screen);

            usernameEditText = findViewById(R.id.userName);
            passwordEditText = findViewById(R.id.passWord);

            // Login Button
            Button loginButton = findViewById(R.id.loginButton);
            loginButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Retrieve the username and password from EditText fields
                    String username = usernameEditText.getText().toString();
                    String password = passwordEditText.getText().toString();

                    // Check if the username and password are valid
                    if (isValidLogin(username, password)) {
                        // Start the new activity
                        Intent intent = new Intent(MainActivity.this, Inventory_grid.class);
                        startActivity(intent);
                        finish(); // Finish current activity to prevent user from going back
                    } else {
                        // Display an error message to the user
                        Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            // New Account Button
            Button newAccountButton = findViewById(R.id.newAccountButton);
            newAccountButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openAccountCreationFragment();
                }
            });

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }


    // Helper methods to improve readability

    private void openAccountCreationFragment() {
        // Create an instance of the fragment
        AccountCreationFragment fragment = new AccountCreationFragment();

        // Start a fragment transaction
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction transaction = fragmentManager.beginTransaction();

        // Replace the contents of the container with the new fragment
        transaction.replace(R.id.fragmentContainer, fragment);

        // Add the transaction to the back stack
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }

    private boolean isValidLogin(String username, String password) {
        // Query the database to check if there is a user with the provided username and password
        SQLiteDatabase database = new Helper(this).getReadableDatabase();
        Cursor cursor = database.query(
                UserContract.UserEntry.TABLE_NAME,
                null,
                UserContract.UserEntry.COLUMN_USERNAME + " = ? AND " + UserContract.UserEntry.COLUMN_PASSWORD + " = ?",
                new String[]{username, password},
                null,
                null,
                null
        );

        // Check if the cursor contains any rows (i.e., if a matching user was found)
        boolean isValid = cursor != null && cursor.getCount() > 0;

        // Close the cursor and database connection
        if (cursor != null) {
            cursor.close();
        }
        database.close();

        return isValid;
    }


}