package com.zybooks.projecttwo.db;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;
import java.util.Map;

public class Helper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    // For logging database iteration
    private static final int DATABASE_VERSION = 6;

    public Helper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_USERS_TABLE = "CREATE TABLE " +
                UserContract.UserEntry.TABLE_NAME + " (" +
                UserContract.UserEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserContract.UserEntry.COLUMN_USERNAME + " TEXT NOT NULL, " +
                UserContract.UserEntry.COLUMN_PASSWORD + " TEXT NOT NULL);";

        db.execSQL(SQL_CREATE_USERS_TABLE);

        final String SQL_CREATE_ITEMS_TABLE = "CREATE TABLE " +
                UserContract.ItemGrid.TABLE_NAME + " (" +
                UserContract.ItemGrid._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                UserContract.ItemGrid.COLUMN_ITEMNAME + " TEXT NOT NULL, " +
                UserContract.ItemGrid.COLUMN_ITEMCOUNT + " TEXT NOT NULL);";

        db.execSQL(SQL_CREATE_ITEMS_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + UserContract.UserEntry.TABLE_NAME);
        db.execSQL("DROP TABLE IF EXISTS " + UserContract.ItemGrid.TABLE_NAME);

        // Recreate tables by calling onCreate
        onCreate(db);
    }

    public Map<String, Integer> getAllItemNamesAndCountsFromDatabase(Context context) {
        Map<String, Integer> itemMap = new HashMap<>();

        // Get a readable database
        SQLiteDatabase db = new Helper(context).getReadableDatabase();

        // Define projection (columns to retrieve)
        String[] projection = {
                UserContract.ItemGrid.COLUMN_ITEMNAME,
                UserContract.ItemGrid.COLUMN_ITEMCOUNT
        };

        // Perform a query on the itemInfo table
        Cursor cursor = db.query(
                UserContract.ItemGrid.TABLE_NAME,   // The table to query
                projection,                        // The columns to return
                null,                      // The columns for the WHERE clause
                null,                  // The values for the WHERE clause
                null,                       // Don't group the rows
                null,                        // Don't filter by row groups
                null                        // The sort order
        );

        // Iterate through the cursor to populate the itemMap
        if (cursor != null) {
            while (cursor.moveToNext()) {
                String itemName = cursor.getString(cursor.getColumnIndexOrThrow(UserContract.ItemGrid.COLUMN_ITEMNAME));
                int itemCount = cursor.getInt(cursor.getColumnIndexOrThrow(UserContract.ItemGrid.COLUMN_ITEMCOUNT));
                itemMap.put(itemName, itemCount);
            }
            cursor.close();
        }

        // Close the database connection
        db.close();

        return itemMap;
    }
}