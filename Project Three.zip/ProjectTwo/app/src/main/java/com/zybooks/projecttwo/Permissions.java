package com.zybooks.projecttwo;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class Permissions extends AppCompatActivity {
    private static final int PERMISSION_REQUEST_CODE = 1001;
    private static final String PERMISSION = android.Manifest.permission.SEND_SMS;

    private static final String SEND_SMS_PERMISSION = Manifest.permission.SEND_SMS;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.permissions); // Set the layout for this activity
        EdgeToEdge.enable(this);


        Button backButton = findViewById(R.id.Back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Permissions.this, Inventory_grid.class);
                startActivity(intent);
            }
        });


        if (ContextCompat.checkSelfPermission(this, PERMISSION) == PackageManager.PERMISSION_GRANTED) {
            // Permission is already granted
        }
            else{
                // Permission is not granted, request it
                ActivityCompat.requestPermissions(this, new String[]{PERMISSION}, PERMISSION_REQUEST_CODE);
            }

    }

    }