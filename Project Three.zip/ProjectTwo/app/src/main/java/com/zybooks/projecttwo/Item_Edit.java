package com.zybooks.projecttwo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.projecttwo.data.UserRepository;

public class Item_Edit extends AppCompatActivity {
    private EditText newCount;

    UserRepository userRepository = new UserRepository(this);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_edit); // Set the layout for this activity
        EdgeToEdge.enable(this);

        newCount = findViewById(R.id.countUpdate);
        String itemName = getIntent().getStringExtra("itemName");

        Button editButton = findViewById(R.id.SubmitButton);
        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int newQuant = Integer.parseInt(newCount.getText().toString());
                userRepository.updateItemQuantity(itemName, newQuant);

                Intent intent = new Intent(Item_Edit.this, Inventory_grid.class);
                startActivity(intent);
            }
        });
    }
}
