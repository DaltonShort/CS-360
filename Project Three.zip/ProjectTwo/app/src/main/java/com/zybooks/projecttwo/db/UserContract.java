package com.zybooks.projecttwo.db;

import android.provider.BaseColumns;

public final class UserContract {
    // To prevent accidental instantiation
    private UserContract() {}

    // Inner class defining the table contents
    public static class UserEntry implements BaseColumns {
        public static final String TABLE_NAME = "users";
        public static final String COLUMN_USERNAME = "username";
        public static final String COLUMN_PASSWORD = "password";
    }

    public static class ItemGrid implements BaseColumns {
        public static final String TABLE_NAME = "itemInfo";

        public static final String COLUMN_ITEMNAME = "itemName";

        public static final String COLUMN_ITEMCOUNT = "item_count";
    }
}
