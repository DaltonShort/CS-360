package com.zybooks.projecttwo;

import static androidx.core.content.ContentProviderCompat.requireContext;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.projecttwo.data.UserRepository;
import com.zybooks.projecttwo.db.Helper;
import com.zybooks.projecttwo.db.UserContract;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Inventory_grid extends AppCompatActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventory_grid); // Set the layout for this activity
        EdgeToEdge.enable(this);

        // Populate the GridLayout from the database
        populateGridLayoutFromDatabase();

        // Set the tag for the delete button
        Button deleteButton = findViewById(R.id.deleteButton);
        deleteButton.setTag("PlaceholderItem"); // Set the tag as the item name
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the item name from the tag
                String itemName = (String) v.getTag();
                // Call the method to delete the item from the database
                deleteItemFromDatabase(itemName);
            }
        });

        Button addItemButton = findViewById(R.id.addItemButton);
        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Inventory_grid.this, item_add.class);
                startActivity(intent);
            }
        });

        Button permissions = findViewById(R.id.permissions);
        permissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Inventory_grid.this, Permissions.class);
                startActivity(intent);
            }
        });
    }

    private String getItemNameAtPosition(int position) {
        // Implement logic to get the item name at the specified position in the grid view
        return "Item " + (position + 1);
    }

    private void deleteItemFromDatabase(String itemName) {
        UserRepository userRepository = new UserRepository(this);
        userRepository.deleteItem(itemName);
        Toast.makeText(this, "Item deleted successfully", Toast.LENGTH_SHORT).show();
    }
    Helper helper = new Helper(this);
    private void populateGridLayoutFromDatabase() {
        // Get all item names and counts from the database
        Map<String, Integer> itemMap = helper.getAllItemNamesAndCountsFromDatabase(this);

        // Find the GridLayout in your layout
        GridLayout gridLayout = findViewById(R.id.grid);

        // Loop through each item in the map
        String itemName = null;
        for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
            itemName = entry.getKey();
            int itemCount = entry.getValue();

            checkAndSendLowQuantityWarning(itemName, itemCount);

            // Create TextView for item name
            TextView itemNameTextView = new TextView(this);
            itemNameTextView.setText(itemName);
            GridLayout.LayoutParams itemNameParams = new GridLayout.LayoutParams();
            itemNameParams.columnSpec = GridLayout.spec(0);
            itemNameTextView.setLayoutParams(itemNameParams);
            gridLayout.addView(itemNameTextView);

            // Create TextView for item count
            TextView itemCountTextView = new TextView(this);
            itemCountTextView.setText(String.valueOf(itemCount));
            GridLayout.LayoutParams itemCountParams = new GridLayout.LayoutParams();
            itemCountParams.columnSpec = GridLayout.spec(1);
            itemCountTextView.setLayoutParams(itemCountParams);
            gridLayout.addView(itemCountTextView);

            // Edit Quantity Button
            Button editQuantity = new Button(this);
            editQuantity.setText("Edit Count");
            editQuantity.setTag(itemCount);
            editQuantity.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // retrieve itemName to pass onto next activity
                    String itemName = itemNameTextView.getText().toString();

                    Intent intent = new Intent(Inventory_grid.this, Item_Edit.class);

                    intent.putExtra("itemName", itemName);

                    startActivity(intent);
                }
            });
            GridLayout.LayoutParams editQuantityParams = new GridLayout.LayoutParams();
            editQuantityParams.columnSpec = GridLayout.spec(2);
            editQuantity.setLayoutParams(editQuantityParams);
            gridLayout.addView(editQuantity);


            // Create delete button
            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTag(itemName);
            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String itemName = (String) v.getTag();
                    deleteItemFromDatabase(itemName);
                    gridLayout.removeView(itemNameTextView);
                    gridLayout.removeView(itemCountTextView);
                    gridLayout.removeView(deleteButton);
                    gridLayout.removeView(editQuantity);
                }
            });
            GridLayout.LayoutParams deleteButtonParams = new GridLayout.LayoutParams();
            deleteButtonParams.columnSpec = GridLayout.spec(3);
            deleteButton.setLayoutParams(deleteButtonParams);
            gridLayout.addView(deleteButton);
        }
    }

    private List<String> getAllItemNamesFromDatabase() {
        List<String> itemNames = new ArrayList<>();

        // Instantiate the Helper class
        Helper dbHelper = new Helper(this);

        // Get a readable database instance using the repository
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define a projection that specifies the columns from which you want to fetch data
        String[] projection = {
                UserContract.ItemGrid.COLUMN_ITEMNAME
        };

        // Query the database to fetch all item names
        Cursor cursor = db.query(
                UserContract.ItemGrid.TABLE_NAME,  // The table to query
                projection,                        // The columns to return
                null,                              // The columns for the WHERE clause
                null,                              // The values for the WHERE clause
                null,                              // don't group the rows
                null,                              // don't filter by row groups
                null                               // The sort order
        );

        // Iterate through the cursor to retrieve item names
        while (cursor.moveToNext()) {
            String itemName = cursor.getString(cursor.getColumnIndexOrThrow(UserContract.ItemGrid.COLUMN_ITEMNAME));
            itemNames.add(itemName);
        }

        // Close the cursor and database to release resources
        cursor.close();
        db.close();

        return itemNames;
    }

    private List<String> getAllItemQuantitiesFromDatabase() {
        List<String> itemNames = new ArrayList<>();

        // Instantiate the Helper class
        Helper dbHelper = new Helper(this);

        // Get a readable database instance using the repository
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define a projection that specifies the columns from which you want to fetch data
        String[] projection = {
                UserContract.ItemGrid.COLUMN_ITEMCOUNT
        };

        // Query the database to fetch all item names
        Cursor cursor = db.query(
                UserContract.ItemGrid.TABLE_NAME,  // The table to query
                projection,                        // The columns to return
                null,                              // The columns for the WHERE clause
                null,                              // The values for the WHERE clause
                null,                              // don't group the rows
                null,                              // don't filter by row groups
                null                               // The sort order
        );

        // Iterate through the cursor to retrieve item names
        while (cursor.moveToNext()) {
            String itemCount = cursor.getString(cursor.getColumnIndexOrThrow(UserContract.ItemGrid.COLUMN_ITEMCOUNT));
            itemNames.add(itemCount);
        }

        // Close the cursor and database to release resources
        cursor.close();
        db.close();

        return itemNames;
    }

    private void checkAndSendLowQuantityWarning(String itemName, int itemCount) {
        if (itemCount < 5) {
            String message = "Warning: Item " + itemName + " is running low. Current count: " + itemCount;
            sendSMS("+1234567890", message); // Replace "+1234567890" with the recipient's phone number
            Toast.makeText(this, "Low quantity warning sent for " + itemName, Toast.LENGTH_SHORT).show();
        }
    }

    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            Toast.makeText(this, "SMS sending failed", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
